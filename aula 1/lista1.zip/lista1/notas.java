
import java.util.Random;
import java.util.Scanner;

class notas{
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);

        System.out.print("Quantidade de alunos: ");
        int qtdAlunos = scanner.nextInt();
        
        System.out.print("Quantidade de provas por aluno: ");
        int qtdProvas = scanner.nextInt();

        float[][] matriz = new float [qtdAlunos][qtdProvas];

        System.out.println("Elementos do Array: ");

        Random aleatorio = new Random();
    
        for (int linha = 0; linha < matriz.length; linha++){
            for (int coluna = 0; coluna < matriz[linha].length; coluna ++){
                matriz [linha][coluna] = aleatorio.nextFloat() * 10 ;
            }
        }

    
        int aluno = 1;
        for(var linha: matriz){
            System.out.printf("Aluno " + aluno++ + ": ");
            for (var coluna : linha ){
                System.out.printf ("%.1f ", coluna);
            }
            System.out.println();
        }


        for (int i = 0; i < qtdAlunos; i++) {
            float soma = 0;
            for (int j = 0; j < qtdProvas; j++) {
                soma += matriz[i][j];
            }

            float mediaaluno = soma/qtdProvas;
            if(mediaaluno >= 7.0){
                System.out.printf("\nAluno " + (i + 1) + ": " +  soma + "; Média do aluno: " +  mediaaluno  + ": Aprovado");
            }else if (mediaaluno >= 5.0 && mediaaluno < 6.9){
                
                System.out.printf("\nAluno " + (i + 1) + ": " +  soma + "; Média do aluno: " + mediaaluno + ": Recuperção");
            }else if (mediaaluno < 5.0){
                System.out.printf("\nAluno " + (i + 1) + ": " + soma + "; Média do aluno: " + mediaaluno + ": Reprovado");

            }
        }
        System.err.println("\n");


    }
}